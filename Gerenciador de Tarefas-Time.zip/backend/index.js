const express = require('express');
const admin = require('firebase-admin');
const cors = require('cors');
const serviceAccount = require('./serviceAccountKey.json');

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: 'https://<your-project-id>.firebaseio.com'
});

const db = admin.firestore();
const app = express();
app.use(cors());
app.use(express.json());

// CHAMADAS PARA OBTER TODOS OS DADOS DAS COLLECTIONS
app.get('/members', async (req, res) => {
    try {
      const snapshot = await db.collection('members').get();
      const members = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      res.status(200).json(members);
    } catch (error) {
      res.status(500).send(error.message);
    }
  });

app.get('/tasks', async (req, res) => {
    try {
      const snapshot = await db.collection('tasks').get();
      const tasks = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      res.status(200).json(tasks);
    } catch (error) {
      res.status(500).send(error.message);
    }
  });

// CHAMADAS PARA EDITAR TAREFAS E MEMBROS
app.put('/members/:id', async (req, res) => {
    const { id } = req.params;
    const member = req.body;
    try {
      await db.collection('members').doc(id).set(member, { merge: true });
      res.status(200).send('Member updated');
    } catch (error) {
      res.status(500).send(error.message);
    }
  });

app.put('/tasks/:id', async (req, res) => {
    const { id } = req.params;
    const task = req.body;
    try {
      await db.collection('tasks').doc(id).set(task, { merge: true });
      res.status(200).send('Task updated');
    } catch (error) {
      res.status(500).send(error.message);
    }
  });
  
// OBTER DADOS POR ID
app.get('/members/:id', async (req, res) => {
    const { id } = req.params;
    try {
      const doc = await db.collection('members').doc(id).get();
      if (!doc.exists) {
        res.status(404).send('Member not found');
      } else {
        res.status(200).json({ id: doc.id, ...doc.data() });
      }
    } catch (error) {
      res.status(500).send(error.message);
    }
});

app.get('/tasks/:id', async (req, res) => {
    const { id } = req.params;
    try {
      const doc = await db.collection('tasks').doc(id).get();
      if (!doc.exists) {
        res.status(404).send('Task not found');
      } else {
        res.status(200).json({ id: doc.id, ...doc.data() });
      }
    } catch (error) {
      res.status(500).send(error.message);
    }
});

// OBTER DADOS DO MEMBRO POR EMAIL
app.get('/members', async (req, res) => {
    const { email } = req.query;
    try {
        const querySnapshot = await db.collection('members').where('email', '==', email).get();
        if (querySnapshot.empty) {
            res.status(404).send('Member not found');
            return; // Retornar para evitar enviar uma resposta vazia
        } 
        let memberData = null;
        querySnapshot.forEach((doc) => {
            // Verificar se o email do membro é exatamente igual ao email fornecido
            if (doc.data().email === email) {
                memberData = { id: doc.id, ...doc.data() };
            }
        });
        if (memberData) {
            res.status(200).json(memberData);
        } else {
            res.status(404).send('Member not found');
        }
    } catch (error) {
        res.status(500).send(error.message);
    }
});

// REMOVER MEMBROS E TAREFAS
app.delete('/members/:id', async (req, res) => {
  const { id } = req.params;
  try {
    await db.collection('members').doc(id).delete();
    res.status(200).send('Member deleted');
  } catch (error) {
    res.status(500).send(error.message);
  }
});

app.delete('/tasks/:id', async (req, res) => {
  const { id } = req.params;
  try {
    await db.collection('tasks').doc(id).delete();
    res.status(200).send('Task deleted');
  } catch (error) {
    res.status(500).send(error.message);
  }
});


// CHAMADAS PARA REALIZAR CADASTRO DE MEMBROS E TAREFAS
app.post('/members', async (req, res) => {
  const member = req.body;
  try {
    const docRef = await db.collection('members').doc();
    const newMember = await docRef.set(member);
    res.status(201).send('Member added');
  } catch (error) {
    res.status(500).send(error.message);
  }
});

app.post('/tasks', async (req, res) => {
  const task = req.body;
  try {
    await db.collection('tasks').add(task);
    res.status(201).send('Task added');
  } catch (error) {
    res.status(500).send(error.message);
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
