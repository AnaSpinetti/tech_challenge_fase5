import React from "react";
import { AuthProvider, useAuth } from "./contexts/authContext";
import { useRoutes, Navigate } from "react-router-dom";
import Login from "./components/auth/login"; 
import Register from "./components/auth/register"; 
import Header from "./components/header"; 
import Dashboard from "./components/dashboard"; 
import EditMember from "./components/editMember";
import EditTask from "./components/editTask";
import AddMember from "./components/addMember";
import AddTask from "./components/addTask";

import "./style/global.scss";
import CargaTrabalho from "./components/carga-trabalho";

function App() {
  const auth = useAuth(); 

  const routesArray = [
    {
      path: "*",
      element: <Login />,
    },
    {
      path: "/login",
      element: <Login />,
    },
    {
      path: "/register",
      element: <Register />,
    },
    {
      path: "/home",
      element: <Dashboard />,
    },
    {
      path: "/edit-member/:id",
      element: <EditMember />,
    },
    {
      path: "/add-task/",
      element: <AddTask />,
    },
    {
      path: "/add-member/",
      element: <AddMember />,
    },
    {
      path: "/tasks/:id",
      element: <EditTask />,
    },
    {
      path: "/carga-trabalho",
      element: <CargaTrabalho />,
    },
  ];
  let routesElement = useRoutes(routesArray);
  return (
    <AuthProvider>
      <Header />
      <div>{routesElement}</div>
    </AuthProvider>
  );
}

export default App;
