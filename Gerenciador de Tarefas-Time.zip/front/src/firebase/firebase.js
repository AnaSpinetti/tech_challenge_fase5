import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyCOUKZnonTUXnDpWxTQjVcYD8Hg9eaMn8U",
  authDomain: "techchallenge-5.firebaseapp.com",
  projectId: "techchallenge-5",
  storageBucket: "techchallenge-5.appspot.com",
  messagingSenderId: "100261950769",
  appId: "1:100261950769:web:da6b0d695bbd89a74d2c10"
  };

const app = initializeApp(firebaseConfig);
const auth = getAuth(app)


export { app, auth };
