import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './addTask.scss'

const AddTask = () => {
  const [description, setDescription] = useState('');
  const [deadline, setDeadline] = useState('');
  const [estimatedTimeHours, setEstimatedTimeHours] = useState('');
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      // Busca o ID do membro com base no email fornecido
      const memberResponse = await axios.get(`http://localhost:5000/members?email=${email}`);
      const memberId = memberResponse.data[0].id; 

      // Envia a requisição para adicionar a tarefa
      await axios.post('http://localhost:5000/tasks', {
        description,
        deadline,
        estimated_time_hours: estimatedTimeHours,
        member: memberId,
        status: 'Em andamento'
      });

      navigate('/dashboard');
    } catch (error) {
      console.error('Error adding task:', error);
      setError('Ocorreu um erro ao adicionar a tarefa. Por favor, tente novamente mais tarde.');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <label>
        Description:
        <input type="text" value={description} onChange={(e) => setDescription(e.target.value)} />
      </label>
      <label>
        Deadline:
        <input type="date" value={deadline} onChange={(e) => setDeadline(e.target.value)} />
      </label>
      <label>
        Estimated Time (Hours):
        <input type="number" value={estimatedTimeHours} onChange={(e) => setEstimatedTimeHours(e.target.value)} />
      </label>
      <label>
        User Email:
        <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
      </label>

      {error && <p style={{ color: 'red' }}>{error}</p>}

      <button type="submit">Add Task</button>
    </form>
  );
};

export default AddTask;
