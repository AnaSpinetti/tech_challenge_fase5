import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';

import './editTask.scss'

const EditTask = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [task, setTask] = useState({ description: '', deadline: '', estimated_time_hours: '', member: '', status: 'Em andamento' });
  const [memberEmail, setMemberEmail] = useState('');
  const [statusTask, setStatusTask] = useState('Em andamento');
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchTask = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/tasks/${id}`);
        setTask(response.data);

        const memberResponse = await axios.get(`http://localhost:5000/members/${response.data.member}`);
        setMemberEmail(memberResponse.data.email);
      } catch (error) {
        console.error('Error fetching task:', error);
      }
    };

    fetchTask();
  }, [id]);


  const handleChange = (e) => {
    const { name, value } = e.target;

    setTask((prevTask) => ({
      ...prevTask,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      // Buscar o ID do membro com base no email fornecido
      const memberResponse = await axios.get(`http://localhost:5000/members?email=${memberEmail}`);
      const memberId = memberResponse.data[0].id; // Assumindo que a API retorna um array de membros e usamos o primeiro item

      // Atualizar o estado task com o ID do membro e o status selecionado
      const updatedTask = { ...task, member: memberId, status: statusTask };

      // Enviar a requisição para atualizar a tarefa
      await axios.put(`http://localhost:5000/tasks/${id}`, updatedTask);
      navigate('/dashboard');
    } catch (error) {
      console.error('Error updating task:', error);
      setError('Ocorreu um erro ao atualizar a tarefa. Por favor, tente novamente mais tarde.');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <label>
        Tarefa:
        <input
          type="text"
          name="description"
          value={task.description}
          onChange={handleChange}
        />
      </label>

      <label>
        Prazo:
        <input
          type="date"
          name="deadline"
          value={task.deadline}
          onChange={handleChange}
        />
      </label>

      <label>
        Horas Estimadas:
        <input
          type="number"
          name="estimated_time_hours"
          value={task.estimated_time_hours}
          onChange={handleChange}
        />
      </label>

      <label>
        Usuário Responsável:
        <input
          type="email"
          name="memberEmail"
          value={memberEmail}
          onChange={(e) => setMemberEmail(e.target.value)}
        />
      </label>

      <label>
        Status:
        <select value={statusTask} onChange={(e) => setStatusTask(e.target.value)}>
          <option value="Em andamento">Em andamento</option>
          <option value="Concluída">Concluída</option>
        </select>
      </label>

      {error && <p style={{ color: 'red' }}>{error}</p>}

      <button type="submit">Atualizar Tarefa</button>
    </form>
  );
};

export default EditTask;
