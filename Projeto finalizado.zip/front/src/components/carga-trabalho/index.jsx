import React, { useState, useEffect } from 'react';
import axios from 'axios';

const CargaTrabalho = () => {
  const [members, setMembers] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [memberWorkload, setMemberWorkload] = useState([]);

  useEffect(() => {
    const fetchMembers = async () => {
      try {
        const response = await axios.get('http://localhost:5000/members');
        setMembers(response.data);
      } catch (error) {
        setError("Erro ao obter membros");
        console.error('Error fetching members:', error);
      }
    };

    const fetchTasks = async () => {
      try {
        const response = await axios.get('http://localhost:5000/tasks');
        setTasks(response.data);
      } catch (error) {
        setError("Erro ao obter tarefas");
        console.error('Error fetching tasks:', error);
      }
    };

    const fetchData = async () => {
      setIsLoading(true);
      setError(null);
      try {
        await Promise.all([fetchMembers(), fetchTasks()]);
      } catch (error) {
        setError("Erro ao buscar dados");
        console.error('Error fetching data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
    // Função para calcular a carga de trabalho por membro
    const calculateMemberWorkload = () => {
      const workloadMap = new Map();
      
      // Itera sobre as tarefas para calcular a carga de trabalho por membro
      tasks.forEach(task => {
        const memberID = task.member;
        const estimatedTime = task.estimated_time_hours;

        if (workloadMap.has(memberID)) {
          // Se o membro já está no mapa, soma o tempo estimado
          const currentWorkload = workloadMap.get(memberID);
          workloadMap.set(memberID, Number(currentWorkload) + Number(estimatedTime));
        } else {
          // Se o membro não está no mapa, inicializa com o tempo estimado
          workloadMap.set(memberID, estimatedTime);
        }
      });

      // Converte o mapa para um array de objetos para fácil manipulação no render
      const memberWorkloadArray = [];
      workloadMap.forEach((value, key) => {
        const member = members.find(member => member.id === key);
        if (member) {
          memberWorkloadArray.push({
            memberId: key,
            memberName: member.name,
            workload: value
          });
        }
      });

      setMemberWorkload(memberWorkloadArray);
    };

    if (tasks.length > 0 && members.length > 0) {
      calculateMemberWorkload();
    }
  }, [tasks, members]);

  if (isLoading) {
    return <h1>Carregando...</h1>;
  }

  if (error) {
    return <h1>{error}</h1>;
  }

  return (
    <div>
      <h1>Carga de Trabalho</h1>
      {memberWorkload.map(member => (
        <div key={member.memberId}>
          <p>{member.memberName}: {member.workload} horas</p>
        </div>
      ))}
    </div>
  );
};

export default CargaTrabalho;
