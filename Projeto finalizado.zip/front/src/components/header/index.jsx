import React from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../../contexts/authContext'
import { doSignOut } from '../../firebase/auth'
import './header.scss'

const Header = () => {
    const navigate = useNavigate()
    const { userLoggedIn } = useAuth()
    return (
        <nav>
            {

                userLoggedIn
                    ?
                    <>
                        <button className='btnHeader' onClick={() => { doSignOut().then(() => { navigate('/login') }) }}>Sair</button>
                        <button className='btnHeader' onClick={() => { navigate('/dashboard') }}>Home</button>
                        <button className='btnHeader' onClick={() => { window.location.href = '/carga-trabalho' }}>Carga de Trabalho</button>
                    </>
                    :
                    <>
                        <Link to={'/login'}>Login</Link>
                        <Link to={'/register'}>Cadastre-se</Link>
                    </>
            }

        </nav>
    )
}

export default Header